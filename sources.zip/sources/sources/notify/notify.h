#ifndef NOTIFY_H
#define NOTIFY_H

#include "notify_global.h"
#include "domain.h"
#include "notification.h"

#endif // NOTIFY_H
