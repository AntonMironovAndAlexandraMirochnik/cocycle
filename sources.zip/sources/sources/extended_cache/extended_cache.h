#ifndef EXTENDED_CACHE_H
#define EXTENDED_CACHE_H

#include "extended_cache_global.h"
#include "extended_cache_object.h"
#include "extended_cache_impl.h"

#endif // EXTENDED_CACHE_H
